//Name: Aidan McGrath
//Section: CSCE 314 700
//UIN: 228008747

package squareList;

public class InnerSquareList {
	
	Node head;
	
	

	

/////////////////////////////////////////R E Q U I R E D     F U N C T I O N S////////////////////////////////////////////////////
	
	//Merge function, adds all nodes of data to our inner square list and deletes all nodes in data
	public void merge(InnerSquareList data) {
		while(!(data.isEmpty())) {
			//Looping until data is empty, keep adding the first node in data to the end of this, then remove the first node in data
			this.insert(data.head.data);
			data.removeFirst();
		}
		//At this point, this will include all values in data, and data will be empty
	}
	
	
	
	
	//Size function
	public Integer size() {
		if(this.isEmpty()) {
			return 0;
		}
		//Initializes result as 1, because at this point we have already deemed that the list is not empty
		Integer result = 1;
		Node traverse = this.head;
		//Traverse the list until the end, adding 1 to result each time
		while(traverse.next != null) {
			traverse = traverse.next;
			result++;
		}
		return result;
	}
	
	
	
	//Split function, first half of the list will be kept in the list, second half will be added to newList and returned
	//NOTE: If there are an odd number of elements in the list, the newList will have 1 more than the original list at the end
	public InnerSquareList split() {
		InnerSquareList newList = new InnerSquareList();
		InnerSquareList tempList = new InnerSquareList();
		//Using tempList to store the values of the first half so I can continue to use my removeFirst() function
		//This could be done without a temp list, but the first half of the list would end up in newList, instead of the second half
		int index = 0;
		//Add the first half of the list to tempList
		while(index <= this.size()/2) {
			tempList.insert(this.head.data);
			this.removeFirst();
			index++;
		}
		//Adds the second half of the list to newList
		while(!(this.isEmpty())) {
			newList.insert(this.head.data);
			this.removeFirst();
		}
		//Adds the first half of the now empty list back to itself and removes all nodes in tempList
		while(!(tempList.isEmpty())){
			this.insert(tempList.head.data);
			tempList.removeFirst();
		}
		return newList;
	}
	
/////////////////////////////////////////R E Q U I R E D     F U N C T I O N S////////////////////////////////////////////////////
	
	
	
//////////////////////////////////////////H E L P E R    F U N C T I O N S////////////////////////////////////////////////////////
	
	//Helper function to insert a new node at the end of our InnerSquareList
	public InnerSquareList insert(Integer data) {
		Node newNode = new Node(data);
		
		//If inner list is empty, simply set the head of the list to our new node
		if(this.head == null) {
			this.head = newNode;
		} else {
			//traverse will run through the list until it reaches the end
			Node traverse = this.head;
			while(traverse.next != null) {
				traverse = traverse.next;
			}
			
			//at this point, we are at the end of the inner list
			traverse.next = newNode;
		}
		return this;
	}

	//Helper function to insert a new node at the beginning of our InnerSquareList
	public InnerSquareList insertFirst(Integer data) {
		Node newNode = new Node(data);
		
		//If inner list is empty, simply set the head of the list to our new node
		if(this.head == null) {
			this.head = newNode;
		} else {
			Node temp = this.head;
			this.head = newNode;
			this.head.next = temp;
		}
		return this;
	}
	
	//Helper function to insert a new node at a given position
	public void insertAt(int pos, Integer data) {
		Node newNode = new Node(data);
		
		if(this.head != null && pos == 0) {
			newNode.next = this.head;
			this.head = newNode;
			return;
		}
		
		Node current = this.head;
		Node prev = null;
		for(int i = 0; i < pos; i++) {
			prev = current;
			current = current.next;
			if(current == null) {
				break;
			}
		}
		newNode.next = current;
		prev.next = newNode;
		
	}
	//Helper function to tell us if an inner square list is empty
	public Boolean isEmpty() {
		return(this.head == null);
	}
	
	//Helper function to remove the first node in our inner square list
	public InnerSquareList removeFirst() {
		if(this.head == null) {
			return null;
		}
		this.head = this.head.next;
		return this;
	}
	
	//Helper function to remove from the inner square list at a specific point
	public void removeAt(int pos) {
		if(this.isEmpty()) {
			return;
		}
		if(pos == 0) {
			this.removeFirst();
			return;
		}
		Node current = this.head;
		Node prev = null;
		for(int i = 0; i < pos; i++) {
			prev = current;
			current = current.next;
			if(current.next == null) {
				break;
			}
		}
		prev.next = current.next;
	}
	
	//Helper function to change the value of a node at a specific point
	public void setAt(int pos, Integer data) {
		if(this.isEmpty()) {
			return;
		}
		Node current = this.head;
		
		for(int i = 0; i < pos; i++) {
			
			current = current.next;
			if(current == null) {
				break;
			}
		}
		current.data = data;
	}
	//printList helper function for testing purposes
	public void printList() {
		Node current = this.head;
		while(current != null) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println();
	}
	
//////////////////////////////////////////H E L P E R    F U N C T I O N S////////////////////////////////////////////////////////
	
	//Main function for testing stuff
//	public static void main(String[] args) {
//		InnerSquareList test = new InnerSquareList();
//		InnerSquareList test2 = new InnerSquareList();
//		test.insert(1);
//		test.insert(2);
//		test.insert(3);
//		test2.insert(5);
//		test2.insert(7);
//		test2.insert(8);
//		test.printList();
//		test2.printList();
//		test.merge(test2);
//		test.insert(98);
//		test.printList();
//		test.split().printList();
//		test.printList();
//		test.setAt(0, 90);
//		test.printList();
//		
//		
//		
//	}
}