//Name: Aidan McGrath
//Section: CSCE 314 700
//UIN: 228008747

package squareList;

public class BadDataException extends Exception{
	

	public BadDataException(String errorMessage) {
		super(errorMessage);
	}
}
