//Name: Aidan McGrath
//Section: CSCE 314 700
//UIN: 228008747

package squareList;
import java.util.LinkedList;
import java.util.Scanner;
import java.io.*;
import java.lang.Math;



public class SquareList {
	LinkedList<InnerSquareList> list = new LinkedList<InnerSquareList>();
	InnerSquareList starter = new InnerSquareList();
	
	
	public SquareList(){
		list.add(starter);
	}
	
	
	
/////////////////////////////////////////R E Q U I R E D     F U N C T I O N S////////////////////////////////////////////////////

	//Consolidate function
	public void consolidate() {
		
		//Variables for the current index, the minimum size of an inner list, and the maximum size of an inner list
		int index = 0;
		double minSize = Math.sqrt(this.size()) / 2;
		double maxSize = Math.sqrt(this.size()) * 2;
		
		//Loop through each "Node" in our square list
		while(index < this.list.size()) {
			
			//If an inner square list is empty, remove it. 
			if(this.list.get(index).isEmpty()) {
				this.list.remove(index);
			}
			
			//If two adjacent short lists exist, merge them into the first list, remove the second
			//This will only run if we are not on the final inner list
			if(index < this.list.size() - 1) {
				if(this.list.get(index).size() <= minSize && this.list.get(index + 1).size() <= minSize){
					this.list.get(index).merge(this.list.get(index + 1));
					this.list.remove(index + 1);
				}
			}
			
			//If inner list length is "long", split it, add the second half as a new inner list in the spot to the right of the first half 
			if(this.list.get(index).size() > maxSize) {
				this.list.add(index+1, this.list.get(index).split());
			}
			
			//Increment index
			index++;
		}
	}

	//addFirst function
	public void addFirst(Integer data) {
		this.list.get(0).insertFirst(data);
		this.consolidate();
	}
	
	//addLast function
	public void addLast(Integer data) {
		this.list.get(this.list.size() - 1).insert(data);
		this.consolidate();
	}
	
	//removeFirst function
	public Integer removeFirst() {
		if(this.size() == 0) {
			return null;
		}
		Integer result = this.list.get(0).head.data;
		this.list.get(0).removeFirst();
		this.consolidate();
		return result;
	}
	
	//add function
	public void add(int pos, Integer data) {
		//Note: Exact same beginning part as the get function
		int index = 0;
		
		//Loop through our square list until we are in the inner square list that we know pos is a part of
		while(this.list.get(index).size() < pos) {
			pos -= this.list.get(index).size();
			index++;
		}
		this.list.get(index).insertAt(pos, data);
		this.consolidate();
	}
	
	//remove function
	public Integer remove(int pos) {
		if(this.size() == 0) {
			return null;
		}
		if(this.size() <= pos) {
			System.out.println("Position is out of bounds.");
			return null;
		}
		//Note: Exact same beginning part as the get function
		int index = 0;
		
		//Loop through our square list until we are in the inner square list that we know pos is a part of
		while(this.list.get(index).size() <= pos) {
			pos -= this.list.get(index).size();
			index++;
		}
		this.list.get(index).removeAt(pos);
		this.consolidate();
		return 0;
	}
	
	//get function
	public Integer get(int pos) {
		
		int index = 0;
		
		//Loop through our square list until we are in the inner square list that we know pos is a part of
		while(this.list.get(index).size() <= pos) {
			pos -= this.list.get(index).size();
			index++;
		}
		
		//At this point, loop through the inner square list until we get to the correct position
		Node current = this.list.get(index).head;
		while(pos > 0) {
			current = current.next;
			pos--;
		}
		
		//return the data at the correct position
		return current.data;
	}
	
	//set function
	public void set(int pos, Integer data) {
		//Note: Exact same beginning part as the get function
		int index = 0;
		
		//Loop through our square list until we are in the inner square list that we know pos is a part of
		while(this.list.get(index).size() <= pos) {
			pos -= this.list.get(index).size();
			index++;
		}
		this.list.get(index).setAt(pos, data);
	}
	
	//size function
	public int size() {
		int result = 0;
		int index = 0;
		while(index < this.list.size()) {
			result += this.list.get(index).size();
			index++;
		}
		return result;
	}

	//indexOf function
	public int indexOf(Integer data) {
		int pos = 0;
		
		//Looping through each list in the square list
		for(int i = 0; i < this.list.size(); i++) {
			Node current = this.list.get(i).head;
			
			//Loop while there is a next node to check
			while(current.next != null) {
				
				//If at any time the node's data matches the input data, return the position
				if(current.data == data) {
					return pos;
				}
				//Otherwise, we increment current and pos
				current = current.next;
				pos++;
			}
			//At this point we are at the last element in the inner square list, so we must check once more
			if(current.data == data) {
				return pos;
			}
			//If we are here, that means data was not found in this inner square list, and we will either return -1 or move to the next inner square list
			pos++;
		}
		return -1;
	}
	
	//debugging dump function
	public void dump() {
		System.out.println("Square List Size: " + this.size() + "\n");
		for(int i = 0; i < this.list.size(); i++) {
			System.out.print("Inner List " + (i + 1) + ": ");
			this.list.get(i).printList();
			System.out.print("Inner List " + (i + 1) + " Size: " + this.list.get(i).size() + "\n\n");
		}
	}

	//openDataFile function
	//NOTE: This function must include "throws BadDataException" to run properly
	//If this method is run in the main function, then the main function must also include "throws BadDataException"
	void openDataFile(String filename) throws BadDataException{
		//Creates new scanner called infile and attempts to assign it to a new FileReader with the input file name
		Scanner infile = null;
		try {
			infile = new Scanner(new FileReader(filename));
			
		}
		//If file is not found, throw exception, print stack trace, and exit
		catch (FileNotFoundException e) {
			System.out.println("Data File Not Found");
			e.printStackTrace();
			//Exit the code
			System.exit(0);
		}
		//At this point we have confirmed that the file exists, and must check to see if the data in the file is valid
		while(infile.hasNextLine()) {
			//If the data is not an integer, throw BadDataException
			if(!(infile.hasNextInt())) {
				throw new BadDataException("Data Error in File");
			}
			//Otherwise, add the line to the end of our square list
			this.addLast(Integer.parseInt(infile.nextLine()));
		}
		//Close input file at the end of function
		infile.close();
	}
	/////////////////////////////////////////R E Q U I R E D     F U N C T I O N S////////////////////////////////////////////////////

	
	
	
//////////////////////////////////////////H E L P E R    F U N C T I O N S////////////////////////////////////////////////////////

	//Print function for testing purposes
	public void printSquare() {
		int index = 0;
		while(index < this.list.size()) {
			this.list.get(index).printList();
			index++;
		}
	}
	

	
	
	
//////////////////////////////////////////H E L P E R    F U N C T I O N S////////////////////////////////////////////////////////

//	public static void main(String[] args) throws BadDataException{
//		SquareList newSquare = new SquareList();
//		InnerSquareList test = new InnerSquareList();
//		
//		test.insert(1);
//		test.insert(2);
//		test.insert(3);
//		test.insert(4);
//		test.insert(5);
//		test.insert(6);
//		test.insert(7);
//		test.insert(8);
//		test.insert(9);
//		test.insert(10);
//		test.insert(11);
//		test.insert(12);
//		test.insert(13);
//		newSquare.list.add(test);
//		newSquare.consolidate();
//		newSquare.dump();
//		newSquare.set(3, 90);
//		newSquare.dump();
//		
//		newSquare.openDataFile("./src/driver/data1.txt");
//		newSquare.dump();
//		
//	}
	
}



