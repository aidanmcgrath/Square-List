//Name: Aidan McGrath
//Section: CSCE 314 700
//UIN: 228008747

package squareList;


public class Node {
	Integer data;
	Node next;
	
	//Node constructor. next is null by default
	Node(int n){
		data = n;
		next = null;
	}
}
